package com.example.festividades

class CardCustomizationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card_customization)

        val design = intent.getParcelableExtra<Design>("DESIGN")
        // Configura la vista con el diseño seleccionado y permite la personalización
    }
}
