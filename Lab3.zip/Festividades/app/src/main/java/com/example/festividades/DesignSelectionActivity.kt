package com.example.festividades

class DesignSelectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_design_selection)

        val festivity = intent.getStringExtra("FESTIVITY")
        val designs = getDesignsForFestivity(festivity)

        val adapter = DesignAdapter(designs) { design ->
            // Navegar a CardCustomizationActivity
            val intent = Intent(this, CardCustomizationActivity::class.java)
            intent.putExtra("DESIGN", design)
            startActivity(intent)
        }

        designRecyclerView.adapter = adapter
    }

    private fun getDesignsForFestivity(festivity: String): List<Design> {
        // Devuelve una lista de diseños basados en la festividad
        // ...
    }
}
